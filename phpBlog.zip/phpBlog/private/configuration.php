<?php
define ('SITE_HEADER_LOGO','');
define ('SITE_FOOTER_LOGO','assets/img-front/footer_logo.png');
define ("TITLE","BLOG");
define ('PAGELIMIT','20');
define ('SITE_NAME',"BLOG");
define ('META_TITLE',"BLOG");
define ('META_KEYWORDS',"");
define ('META_DESCRIPTION',"");
define ('FOOTER_NAME',"".date('Y')." &copy; BLOG");
?>