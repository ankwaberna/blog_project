<div class="page-sidebar nav-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->        
    <ul class="page-sidebar-menu">
        <li class="start active ">
            <a href="dashboard.php">
            <i class="icon-home"></i> 
            <span class="title">Dashboard</span>
            <span class="selected"></span>
            </a>
        </li>
        <li class="start  ">
            <a href="blog.php">
            <i class="icon-font"></i> 
            <span class="title">Blog</span>
            <span class="selected"></span>
            </a>
        </li>
        </ul>
    <!-- END SIDEBAR MENU -->
</div>
		