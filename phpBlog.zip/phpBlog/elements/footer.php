<div class="copyright">
	<?php echo FOOTER_NAME;?>
</div>